#include <lpc23xx.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "shareddefs.h"
#include "sharedinterface.h"
#include "queue.h"
#include "timer.h"
#include "wireless.h"
#include "PCU.h"
#include "i2c.h"
#include "serial.h"
#include "pwm.h"
#include "adc.h"
#include "ADS7828.h"
#include "pcuErrors.h"
#include "pcuPowerControl.h"
#include "mischardware.h"
#include "actuator.h"
#include "lm73.h"
#include "display.h"
#include "flash_nvol.h"
#include "power.h"
#include "pll.h"
#include "irq.h"
#include "ssp.h"
#include "spiFlash.h"
#include "pcuCommands.h"
#include "storedconfig.h"
#include "watchdog.h"
#include "PCUDefs.h"
#include "pcuStatusBoard.h"

//#define DEBUG_IN_PROGRESS

#define WATCHDOG_FEEDING_TIME_MS    1000
#define LAMPS_ENABLE_TIME_MS        10000

#define ADC_SAMPLE_TIME_MS          100
#define ACD_SAMPLE_TICKS_PER_SECOND 10

#define SOLAR_MANUAL_MODE_TIME_MS   (1000*60*5)
#define DCU_RESET_TIME_MS           2000

static void doWork(void);
static TIMERCTL sampleTimer;
static TIMERCTL watchdogFeedingTimer;
static TIMERCTL solarManualModeTimer;
static TIMERCTL lampEnableTimer;
static TIMERCTL dcuResetTimer;
static char* pCompileDate = __DATE__;
static char* pCompileTime = __TIME__;
unsigned short nAlarms;
static BOOL bSolarManualMode = FALSE;
static BOOL bResetDCU = FALSE;
static BOOL bLampsEnabled = FALSE;

void resetDCU()
{
	printf("1-resetDCU\n");
	bResetDCU = TRUE;
	pcuPowerControlSetOutput(ePOWER_OUTPUT_OFF, ePCU_SET_DCU_OUTPUT);
	startTimer(&dcuResetTimer, DCU_RESET_TIME_MS);
}
void setSolarManualMode(BOOL bMode)
{
	bSolarManualMode = bMode;
	if(bMode)
	{
		startTimer(&solarManualModeTimer, SOLAR_MANUAL_MODE_TIME_MS);
	}
}
int main(void)
{
	int k;					// no C program complete without an int
	
// wait f�r Keil.  Heil Keil?
// delay for JTAG	 to catch the processor and put it in reset	
	for(k = 0; k < 10000; k++)
	{}

	/////
	// setup the clocks
	/////
	PLL_CLOCK_SETUP(ePLATFORM_TYPE_PCU);
		
	/////
	// initialize miscellaneous hardware
	/////
	hwGPIOConfig();
				
	hwSetLVD(OFF);
		
	hwInitPowerControlData();
		
	// init vic
	init_VIC();
		
	/////
	// initialize serial port
	/////
	serialInit(ePLATFORM_TYPE_PCU);	
	
	hwSetSysLED();

	/////
	// initialize the timer system
	/////
	timerInit(ePLATFORM_TYPE_PCU);
	
	if(!SSPInit(ePLATFORM_TYPE_PCU))
	{	
		printf("SSPInit Failed!\n");
	}
	
	/////
	// initialize stored configuration
	/////
	storedConfigInit(ePLATFORM_TYPE_PCU);
	
	/////
	// initialize I2C hardware and queue
	/////
	I2CInitialize();
	
	/////
	// now that I2c is setup
	//
	// reset the power PCA9634 power control devices
	/////
	pcuPowerControlReset();
	
	/////
	// intialize the onboard ADC
	/////
	ADCInit();
	
	/////
	// intialize the offboard ADC
	/////
	switch(hwGetBoardRevision())
	{
		case eBoardRev1:
		case eBoardRev2:
			ADS7828Init();
		default:
			break;

		case eBoardRev3:
		case eBoardRev4:
		case eBoardRev5:
		case eBoardRev6:
		case eBoardRev7:
			break;
	}

	
	//====================================
	// Initialize the PCA9555 used for
	// error signal inputs 
	//====================================
	pcuErrorsInit();
	
	//===============================
	// Initialize the two PCA9634
	// used for power output control
	// disable output for now
	// output will be re-enabled
	// after awhile, in the DoWork loop
	//===============================
	hwDisableSystemLedsAndIndicators();
	pcuPowerControlInit();

	//===============================
	// Initialize the PCA9531 used
	// to control the PCU Status 
	// Board LEDs
	//===============================
	pcuStatusBoardInit();
	
	/////
	// initialize the temperature sensor
	/////
	lm73Init();

	/////
	// initialize the sample timer
	/////
	initTimer(&sampleTimer);	
	
	startTimer(&sampleTimer, ADC_SAMPLE_TIME_MS);

	/////
	// show heartbeat for debug
	/////
	timerShowLEDHeartbeat();

	/////
	// initialize the watchdog timer
	// timeout in 25 seconds
	/////
	initTimer(&watchdogFeedingTimer);
	
	startTimer(&watchdogFeedingTimer, WATCHDOG_FEEDING_TIME_MS);
	
	initTimer(&solarManualModeTimer);
	
	/////
	// initialize the Lamp Enable Timer
	// Timeout is 10 seconds
	/////
	initTimer(&lampEnableTimer);
	
	startTimer(&lampEnableTimer, LAMPS_ENABLE_TIME_MS);

	//==================================
	// Note, these do not send I2C commands
	// right now, they just set up state
	// to instruct the power control dowork
	// to do the transfer
	//
	// All of these outputs must be initialized to some known state here
	//==================================
	/////
	// initialize DCU to on
	/////
	pcuPowerControlSetOutput(ePOWER_OUTPUT_ON, ePCU_SET_DCU_OUTPUT); //Supply Power to DCU
	
	/////
	// initialize the LEDs to on for now
	// so we can see something happening
	// they will become under control of LED logic
	// in the DoWork loop
	//////
	pcuPowerControlSetOutput(ePOWER_OUTPUT_ON,ePCU_SET_LED_VLOW_OUTPUT);
	pcuPowerControlSetOutput(ePOWER_OUTPUT_ON,ePCU_SET_LED_CHRGR_OUTPUT);
	pcuPowerControlSetOutput(ePOWER_OUTPUT_ON,ePCU_SET_LED_SYST_OUTPUT);
	pcuPowerControlSetOutput(ePOWER_OUTPUT_ON,ePCU_SET_LED_ALARM_OUTPUT);
	
	/////
	// all others are initialized to off
	/////
	pcuPowerControlSetOutput(ePOWER_OUTPUT_OFF,ePCU_SET_ROW0_OUTPUT);
	pcuPowerControlSetOutput(ePOWER_OUTPUT_OFF,ePCU_SET_ROW1_OUTPUT);
	pcuPowerControlSetOutput(ePOWER_OUTPUT_OFF,ePCU_SET_ROW2_OUTPUT);
	pcuPowerControlSetOutput(ePOWER_OUTPUT_OFF,ePCU_SET_ROW3_OUTPUT);
    pcuPowerControlSetOutput(ePOWER_OUTPUT_OFF, ePCU_SET_AUX0_OUTPUT);
    pcuPowerControlSetOutput(ePOWER_OUTPUT_OFF, ePCU_SET_AUX1_OUTPUT);
	pcuPowerControlSetOutput(ePOWER_OUTPUT_OFF,ePCU_SET_FAN0_OUTPUT);
	pcuPowerControlSetOutput(ePOWER_OUTPUT_OFF,ePCU_SET_FAN1_OUTPUT);
	pcuPowerControlSetOutput(ePOWER_OUTPUT_OFF,ePCU_SET_RADAR_OUTPUT);
	pcuPowerControlSetOutput(ePOWER_OUTPUT_OFF,ePCU_SET_GPS_OUTPUT);
	pcuPowerControlSetOutput(ePOWER_OUTPUT_OFF,ePCU_SET_MODEM_OUTPUT);


	printf("Ready\n");
	printf("Version[%d.%2.2d.%2.2d] cDate[%s] cTime[%s] HWID[%d]\n", 
        (SOFTWARE_VERSION/10000)%100,
        (SOFTWARE_VERSION/100)%100,
        (SOFTWARE_VERSION%100),
        pCompileDate,
        pCompileTime,
        hwGetBoardRevision());


	while(1)
	{
		doWork();
	}
}

static void doWork()
{
    static int oneSecondTickCounter = 0;
    
	if(isTimerExpired(&watchdogFeedingTimer))
	{
		/////
		// feed the watchdog (ADM6320)
		/////
		FIO1SET = (1 << uP_WD_KICK );
		FIO1CLR = (1 << uP_WD_KICK );
  
		/////
		// and restart the feeding timer
		/////
		startTimer(&watchdogFeedingTimer, WATCHDOG_FEEDING_TIME_MS);
	}

	if(!bLampsEnabled)
	{
		if(isTimerExpired(&lampEnableTimer))
		{	
			hwEnableSystemLedsAndIndicators();
			
			bLampsEnabled = TRUE;
		}
	}
		
	I2CQueueDoWork();

  
	pcuErrorsDoWork();
	
	pcuPowerControlDoWork();
	
	pcuStatusBoardDoWork();
	
	serialDoWork();
		
	pwmDoWork();
			
	if(!bSolarManualMode)
	{
		hwSolarChargeControl();
	}
	else
	{
		if(isTimerExpired(&solarManualModeTimer))
		{
			/////
			// solar manual mode timed out
			/////
			bSolarManualMode = FALSE;
		}
	}
	
	if(bResetDCU)
	{
		if(isTimerExpired(&dcuResetTimer))
		{
			bResetDCU = FALSE;
			pcuPowerControlSetOutput(ePOWER_OUTPUT_ON, ePCU_SET_DCU_OUTPUT);
		}
	}

 
    // LM73 temperature read every 2 seconds    
    lm73DoWork();

    
    switch(hwGetBoardRevision())
    {
       case eBoardRev1:
       case eBoardRev2:
           ADS7828DoWork();
       default:
       break;
    }
	
	if(isTimerExpired(&sampleTimer))
	{
        ADCDoWork();
                
        if(++oneSecondTickCounter >= ACD_SAMPLE_TICKS_PER_SECOND)
        {            
            oneSecondTickCounter = 0;
            // MJB
            // printf("BatteryVoltage[%d]\r\n", AdcI2c, AdcReads, ADCGetBatteryVoltage());
           
            if(pcuErrorsGetAlarm(ePCU_CHARGER_ALARM))
            {
                pcuPowerControlSetOutput(ePOWER_OUTPUT_ON, ePCU_SET_LED_CHRGR_OUTPUT);
            }
            else
            {
                pcuPowerControlSetOutput(ePOWER_OUTPUT_OFF,ePCU_SET_LED_CHRGR_OUTPUT);
            }

            if(pcuErrorsGetAlarm(ePCU_VBATT_ALARM))
            {
                pcuPowerControlSetOutput(ePOWER_OUTPUT_ON,ePCU_SET_LED_ALARM_OUTPUT);
                pcuPowerControlSetOutput(ePOWER_OUTPUT_ON,ePCU_SET_LED_VLOW_OUTPUT);
            }
            else
            {
                pcuPowerControlSetOutput(ePOWER_OUTPUT_OFF, ePCU_SET_LED_ALARM_OUTPUT);
                pcuPowerControlSetOutput(ePOWER_OUTPUT_OFF,ePCU_SET_LED_VLOW_OUTPUT);
            }

            // LVD control must be updated once per second
            hwLVDControl();
		}
        
		startTimer(&sampleTimer, ADC_SAMPLE_TIME_MS);
	}
}

