#ifndef COMMANDS_H
#define COMMANDS_H

void commandDoWork(void);
void commandInit(void);
void commandProcessor(eINTERFACE eInterface, HDLCPACKET *pHDLCPacket);

#endif
